import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFF00897B);
const Color secondaryColor = Color(0xFFFF8F00);
const Color dangerColor = Color(0xFFE53935);
const Color warningColor = Color(0xFFFB8C00);
const Color successColor = Color(0xFF43A047);
const Color infoColor = Color(0xFF1E88E5);

Color bmiColor(double bmi) {
  if (bmi < 18.5) return infoColor;
  if (bmi < 25.0) return successColor;
  if (bmi < 30.0) return warningColor;
  return dangerColor;
}
