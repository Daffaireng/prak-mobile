class BmiCalculator {
  final double weightKg;
  final double heightCm;

  BmiCalculator({required this.weightKg, required this.heightCm});

  double get bmi {
    final heightM = heightCm / 100;
    return weightKg / (heightM * heightM);
  }

  String get kategori {
    final b = bmi;
    if (b < 18.5) return 'Kurus';
    if (b < 25.0) return 'Normal';
    if (b < 30.0) return 'Gemuk';
    return 'Obesitas';
  }

  String get saran {
    final b = bmi;
    if (b < 18.5) return 'Tingkatkan asupan nutrisi dan kalori harianmu!';
    if (b < 25.0) return 'Pertahankan pola makan sehat dan olahraga rutin!';
    if (b < 30.0) return 'Perhatikan pola makan dan mulai olahraga teratur.';
    return 'Konsultasikan dengan dokter untuk program diet yang tepat.';
  }
}
