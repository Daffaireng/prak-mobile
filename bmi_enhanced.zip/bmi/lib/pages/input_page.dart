import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/bmi_calculator.dart';
import '../utils/theme.dart';
import 'result_page.dart';

class InputPage extends StatefulWidget {
  const InputPage({super.key});

  @override
  State<InputPage> createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _weightController = TextEditingController();
  final _heightController = TextEditingController();

  String? _selectedCategory;
  String _selectedGender = 'Laki-laki';

  final List<Map<String, dynamic>> _categories = [
    {'value': 'Anak-anak', 'label': 'Anak-anak (5–17 th)'},
    {'value': 'Remaja', 'label': 'Remaja (17–25 th)'},
    {'value': 'Dewasa', 'label': 'Dewasa (25+ th)'},
  ];

  @override
  void dispose() {
    _nameController.dispose();
    _weightController.dispose();
    _heightController.dispose();
    super.dispose();
  }

  void _hitungBMI() {
    if (_formKey.currentState!.validate()) {
      final calculator = BmiCalculator(
        weightKg: double.parse(_weightController.text),
        heightCm: double.parse(_heightController.text),
      );
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ResultPage(
            nama: _nameController.text.trim(),
            bmi: calculator.bmi,
            gender: _selectedGender,
            kategori: _selectedCategory!,
          ),
        ),
      );
    }
  }

  InputDecoration _inputDecoration({
    required String label,
    required String hint,
    required IconData icon,
    String? suffix,
  }) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      prefixIcon: Icon(icon, color: primaryColor),
      suffixText: suffix,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: primaryColor, width: 2),
      ),
      filled: true,
      fillColor: Colors.grey.shade50,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text(
          'Kalkulator BMI',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: primaryColor.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.monitor_weight_outlined,
                        color: primaryColor, size: 32),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'Masukkan data diri kamu untuk mengetahui indeks massa tubuh!',
                        style: TextStyle(fontSize: 13, color: Colors.black87),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Section: Data Diri
              _sectionTitle('Data Diri'),
              const SizedBox(height: 12),
              TextFormField(
                controller: _nameController,
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Nama tidak boleh kosong' : null,
                decoration: _inputDecoration(
                  label: 'Nama Lengkap',
                  hint: 'Masukkan nama lengkap...',
                  icon: Icons.person_outline,
                ),
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _weightController,
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'Wajib diisi';
                        final n = double.tryParse(v);
                        if (n == null || n <= 0 || n > 300) return 'Tidak valid';
                        return null;
                      },
                      decoration: _inputDecoration(
                        label: 'Berat Badan',
                        hint: '65',
                        icon: Icons.fitness_center,
                        suffix: 'kg',
                      ),
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _heightController,
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'Wajib diisi';
                        final n = double.tryParse(v);
                        if (n == null || n < 50 || n > 300) return 'Tidak valid';
                        return null;
                      },
                      decoration: _inputDecoration(
                        label: 'Tinggi Badan',
                        hint: '170',
                        icon: Icons.height,
                        suffix: 'cm',
                      ),
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Section: Kategori Usia
              _sectionTitle('Kategori Usia'),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                validator: (v) =>
                    v == null ? 'Pilih kategori usia' : null,
                value: _selectedCategory,
                decoration: InputDecoration(
                  prefixIcon:
                      const Icon(Icons.category_outlined, color: primaryColor),
                  border:
                      OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey.shade300),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:
                        const BorderSide(color: primaryColor, width: 2),
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                  labelText: 'Kategori Usia',
                ),
                hint: const Text('Pilih kategori...'),
                items: _categories.map((cat) {
                  return DropdownMenuItem<String>(
                    value: cat['value'],
                    child: Text(cat['label']),
                  );
                }).toList(),
                onChanged: (value) => setState(() => _selectedCategory = value),
              ),
              const SizedBox(height: 24),

              // Section: Jenis Kelamin
              _sectionTitle('Jenis Kelamin'),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Column(
                  children: [
                    RadioListTile<String>(
                      title: const Text('Laki-laki'),
                      secondary: const Icon(Icons.male, color: Colors.blue),
                      value: 'Laki-laki',
                      groupValue: _selectedGender,
                      activeColor: primaryColor,
                      onChanged: (v) => setState(() => _selectedGender = v!),
                    ),
                    Divider(height: 1, color: Colors.grey.shade200),
                    RadioListTile<String>(
                      title: const Text('Perempuan'),
                      secondary: const Icon(Icons.female, color: Colors.pink),
                      value: 'Perempuan',
                      groupValue: _selectedGender,
                      activeColor: primaryColor,
                      onChanged: (v) => setState(() => _selectedGender = v!),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),

              ElevatedButton.icon(
                onPressed: _hitungBMI,
                icon: const Icon(Icons.calculate_outlined),
                label: const Text('Hitung BMI'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 52),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.w600,
        color: Colors.black87,
      ),
    );
  }
}
