import 'package:flutter/material.dart';
import '../utils/bmi_calculator.dart';
import '../utils/theme.dart';

class ResultPage extends StatelessWidget {
  final String nama;
  final String gender;
  final String kategori;
  final double bmi;

  const ResultPage({
    required this.nama,
    required this.bmi,
    required this.gender,
    required this.kategori,
    super.key,
  });

  String _getKategori() {
    if (bmi < 18.5) return 'Kurus';
    if (bmi < 25.0) return 'Normal';
    if (bmi < 30.0) return 'Gemuk';
    return 'Obesitas';
  }

  String _getSaran() {
    if (bmi < 18.5) return 'Tingkatkan asupan nutrisi dan kalori harianmu!';
    if (bmi < 25.0) return 'Pertahankan pola makan sehat dan olahraga rutin!';
    if (bmi < 30.0) return 'Perhatikan pola makan dan mulai olahraga teratur.';
    return 'Konsultasikan dengan dokter untuk program diet yang tepat.';
  }

  Color _getBmiColor() => bmiColor(bmi);

  IconData _getKategoriIcon() {
    if (bmi < 18.5) return Icons.trending_down;
    if (bmi < 25.0) return Icons.check_circle_outline;
    if (bmi < 30.0) return Icons.warning_amber_outlined;
    return Icons.dangerous_outlined;
  }

  IconData _getGenderIcon() {
    return gender == 'Laki-laki' ? Icons.male : Icons.female;
  }

  // BMI scale: min 10, max 40
  double get _bmiProgress => ((bmi - 10) / 30).clamp(0.0, 1.0);

  @override
  Widget build(BuildContext context) {
    final kategoriHasil = _getKategori();
    final color = _getBmiColor();

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text(
          'Hasil BMI',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        leading: const BackButton(),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Profile Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 36,
                    backgroundColor: color.withOpacity(0.15),
                    child: Icon(_getGenderIcon(), size: 40, color: color),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    nama,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _chip(label: kategori, icon: Icons.people_outline),
                      const SizedBox(width: 8),
                      _chip(label: gender, icon: _getGenderIcon()),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // BMI Score Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Text(
                    'Indeks Massa Tubuh (BMI)',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    bmi.toStringAsFixed(1),
                    style: TextStyle(
                      fontSize: 64,
                      fontWeight: FontWeight.bold,
                      color: color,
                      height: 1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(_getKategoriIcon(), color: color, size: 20),
                      const SizedBox(width: 6),
                      Text(
                        kategoriHasil,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: color,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // BMI Progress Bar
                  Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          value: _bmiProgress,
                          minHeight: 12,
                          backgroundColor: Colors.grey.shade200,
                          valueColor: AlwaysStoppedAnimation<Color>(color),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          Text('Kurus\n<18.5',
                              textAlign: TextAlign.center,
                              style:
                                  TextStyle(fontSize: 10, color: Colors.grey)),
                          Text('Normal\n18.5–24.9',
                              textAlign: TextAlign.center,
                              style:
                                  TextStyle(fontSize: 10, color: Colors.grey)),
                          Text('Gemuk\n25–29.9',
                              textAlign: TextAlign.center,
                              style:
                                  TextStyle(fontSize: 10, color: Colors.grey)),
                          Text('Obesitas\n≥30',
                              textAlign: TextAlign.center,
                              style:
                                  TextStyle(fontSize: 10, color: Colors.grey)),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Saran Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.lightbulb_outline, color: color),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _getSaran(),
                      style: TextStyle(
                          fontSize: 14, color: Colors.grey.shade800),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Tabel referensi BMI
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Tabel Referensi BMI',
                    style: TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                  const SizedBox(height: 12),
                  _bmiRow('< 18.5', 'Kurus', infoColor, bmi < 18.5),
                  _bmiRow('18.5 – 24.9', 'Normal', successColor,
                      bmi >= 18.5 && bmi < 25),
                  _bmiRow(
                      '25 – 29.9', 'Gemuk', warningColor, bmi >= 25 && bmi < 30),
                  _bmiRow('≥ 30', 'Obesitas', dangerColor, bmi >= 30),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Tombol Hitung Ulang
            ElevatedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.refresh),
              label: const Text('Hitung Ulang'),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryColor,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 52),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _chip({required String label, required IconData icon}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.grey.shade600),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(fontSize: 12, color: Colors.grey.shade700)),
        ],
      ),
    );
  }

  Widget _bmiRow(String range, String label, Color color, bool isActive) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: isActive ? color.withOpacity(0.12) : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border: isActive
            ? Border.all(color: color.withOpacity(0.4))
            : Border.all(color: Colors.transparent),
      ),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(range,
                style: TextStyle(
                    fontSize: 13,
                    fontWeight:
                        isActive ? FontWeight.w600 : FontWeight.normal)),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: isActive ? FontWeight.w700 : FontWeight.normal,
              color: isActive ? color : Colors.grey,
            ),
          ),
          if (isActive) ...[
            const SizedBox(width: 6),
            Icon(Icons.arrow_back_ios, size: 12, color: color),
            Text('kamu', style: TextStyle(fontSize: 11, color: color)),
          ],
        ],
      ),
    );
  }
}
